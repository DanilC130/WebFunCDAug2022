function loginclick(element){
    element.innerText = "Logout"
}
function defclick(element){
    element.remove()
}
function alertninja(element){
    alert("Ninja was liked")
}